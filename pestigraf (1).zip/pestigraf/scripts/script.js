const ciblePrincipaleData = {
    labels: ['Botrytis cinerea', 'Sclérotinia', 'Mineuses', 'Aleurodes', 'Noctuelles', 'Limaces', 'Pucerons', 'Chenilles', 'Mildiou', 'Oïdium', 'Acariens', 'Thrips', 'Fusariose', 'Carpocapse', 'Forficules', 'Psylles', 'Mouches', 'Tordeuses', 'Campagnols', 'Moniliose', 'Tavelure', 'Empoasca vitis', 'Cochenilles', 'Metcalfa pruinosa', 'Défanage', 'Pythium', 'Adventices', 'Eudemis', 'Méligèthes', 'Corky-root', 'Rhizoctonia', 'Maladies telluriques', 'Big vein', 'Phytophthora', 'Punaises phyotphages', 'Rouille blanche', 'Piétin échaudage', 'Altises', 'Charançon de la tige', 'Maladies du pois', 'Pyrale', 'Ralstonia solanacearum', 'Doryphore'],
    data: [21, 33, 16, 48, 10, 20, 128, 20, 14, 63, 32, 24, 1, 16, 10, 6, 16, 12, 1, 1, 2, 1, 10, 1, 3, 4, 1, 4, 5, 1, 4, 5, 1, 3, 1, 1, 3, 2, 1, 6, 2, 1],
    backgroundColors: Array(42).fill(0).map((_, i) => `hsl(${i * 9}, 70%, 60%)`)
};
// groupe cible
const groupeCibleData = {
    labels: ['Ascomycètes', 'Lépidoptères', 'Hémiptères', 'Pucerons', 'Mollusques', 'Oomycètes', 'Acariens', 'Thrips', 'Nématodes', 'Dermaptères', 'Diptères', 'Vertébrés', 'Végétaux', 'Deutéromycète', 'Coloéptères', 'Basidiomycètes', 'Maladies telluriques', 'Maladies aériennes', 'Champignons', 'Bactériose'],
    data: [140, 93, 70, 82, 20, 18, 23, 20, 14, 10, 18, 1, 3, 1, 11, 5, 5, 1, 1, 2],
    backgroundColors: Array.from({ length: 20 }, (_, i) => `hsl(${i * 18}, 70%, 50%)`)
};

// 3. Mode d'Action
const modeActionData = {
    labels: ['Antagonisme et stimulateur', 'Ingestion', 'Parasitisme', 'Asphyxies', 'Parasitoïdes', 'Parasites des oeufs', 'Prédateurs', 'Stimulateur des défenses', 'Antagonisme et stimulateur (sclérotinose)', 'Parasites des sclérotes', 'Fongicide de contact multi-sites', 'Détection/piégeages', 'Plantes attractives', 'Plantes relais', 'Acariens prédateurs', 'Effet barrières', 'Confusion sexuelle', 'Fongicides sytémique', 'Biofumigation', 'Piégeage massif', 'Effet physiologique', 'Effet aération', 'Plantes répulsives', 'Fumigation', 'Répulsif', 'Herbicides', 'Effet attractif', 'Evitement', 'Plantes pièges', 'Prédateurs et parasitoïdes', 'Parasite de oomycètes', 'Dessèchement structures externes', 'Abris pour faune auxiliaire'],
    data: [19, 41, 17, 22, 37, 2, 29, 13, 7, 9, 45, 12, 7, 1, 22, 14, 12, 2, 8, 2, 1, 5, 10, 7, 3, 3, 3, 4, 2, 1, 1, 3, 2],
    backgroundColors: Array(33).fill(0).map((_, i) => `hsl(${i * 11}, 65%, 50%)`)
};

// 4. Type de Traitement
const typeTraitementData = {
    labels: ['Fongicides', 'Insecticides', 'Molluscicides', 'Favorise les auxiliaires', 'Acaricides', 'Nématicides', 'Herbicides', 'Bactéricides'],
    data: [305, 611, 23, 10, 42, 13, 7, 3],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6', '#33FFF6', '#F6FF33', '#FF9233', '#9233FF']
};

// Cultures
const culturesData = {
    labels: ['Laitue', 'Tomate', 'Toutes cultures leg', 'Cultures d\'été', 'Cultures hiver', 'Melon', 'Pommier', 'Artichaut', 'Brocoli', 'Canne à sucre', 'Abricotier', 'Prunier d\'ente', 'Prunier', 'Vigne', 'Kiwi Hayward', 'Clémentine', 'Carotte', 'Haricot', 'Chou-fleur', 'Blé', 'Pomme de terre', 'Fraise', 'Concombre', 'Artichaut, scarole', 'Pêcher/nectarine', 'Colza', 'Tournesol', 'Betterave sucrière', 'Oignon', 'Radis', 'Salade', 'Légumes feuilles, courgette', 'Aubergine, radis, épinard, navet', 'Gerbera', 'Fleurs coupées : renoncules, anémones, pavot, lisianthus, limonium', 'Fleurs coupées : campanule, célosie, chrysanthème, giroflée, lisianthus, muflier, tournesol', 'Choisya ternata (oranger du Mexique)', 'Elaeagnus', 'Viburnum tinus (Laurier tin)', 'Photinia', 'Pélargonium', 'Poinsettia', 'Hibiscus rosa chinensis', 'Chrysanthème', 'Gerbera en pots', 'Maïs', 'Colza, soja', 'Pois chiche'],
    data: [40, 36, 8, 7, 1, 11, 27, 1, 1, 1, 12, 2, 4, 29, 3, 3, 5, 1, 3, 5, 7, 41, 13, 2, 8, 14, 1, 3, 1, 8, 6, 3, 4, 12, 10, 8, 6, 5, 4, 6, 6, 7, 7, 5, 7, 2, 1],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6', '#33FFF6', '#F6FF33']
};

// Parti Traité
const partiTraiteData = {
    labels: ['Aérienne', 'Sol'],
    data: [238, 58],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6']
};

// Pleine Terre ou Abri
const terreOuAbriData = {
    labels: ['Sous abris', 'Plein champ', 'Serres verre', 'Hors sol serre verre (chauffées)', 'Extérieur hors sol', 'Hors sol en plein air', 'Multichapelle froid', 'En pots sous abris puis plein air', 'Hors sol sous abri', 'Hors sol sous serre chauffées', 'Hors sol sous abri plastique'],
    data: [116, 92, 62, 20, 4, 5, 4, 6, 10, 3, 7 ],
    backgroundColors: ['#FF5733', '#33FF57']
};

// Stade d'application
const stadeApplicationData = {
    labels: ['Lâchers de Macrolophus', 'Application répétée', 'Lâchers de 125 ind/m²', 'Lâchers ponctuels', 'Apports réguliers', 'Soufre pour oïdium', 'Traitement préventif', 'Lâchers en préventif', 'Observation régulière', 'Infestation naturelle', 'Traitement avec engrais foliaires', 'Lâchers en juin', 'Lâchers en début de saison', 'Traitement avec phéromones', 'Élevage en sachets', 'Apports sous forme de granulés', 'Traitement curatif sur foyers', 'Lâchers de 17 ind/m²'],
    data: [8, 8, 4, 4, 5, 2, 6, 4, 4, 3, 2, 2, 2, 2, 2, 2, 2],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6']
};

// Satisfaction
const satisfactionData = {
    labels: ['Bon', 'Mitigé', 'Aucun avis émis', 'Insatisfaisant'],
    data: [168, 37, 49, 16 ],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6', '#33FFF6']
};

// Site d'expérimentation
const siteExperimentationData = {
    labels: ['Domaine Expérimental Alénya-Roussillon', 'INRAE Gotheron', 'SECL-Terre d\'essais', 'Saint Marie', 'Sica CENTREX', 'CTIFL de Balandran', 'INRA/BIP', 'AREFE', 'SERFEL', 'INRA de Gotheron', 'Lycée Amboise', 'AREFLEC San Giuliano', 'Lycée agricole de Borgo', 'INVENIO Commensacq', 'SILEBAN Créances', 'SILEBAN Montfarville', 'Pôle légumes', 'Tour en sologne', 'INVENIO Douville', 'INVENIO Ste Livrade sur Lot', 'Producteur - APREL - VERQUIERES', 'Producteur - SAVEOL - PLOUGUERNEAU', 'APREL - Saint Rémy de provence', 'ARELPAL Site B - Pont Saint martin', 'Producteur LCA/CVETMO - Saint Denis en Val', 'SAVEOL Site A - GUIPAVAS', 'SAVEOL Site B - GUIPAVAS', 'Sica CENTREX - Torreilles', 'SEFRA', 'INRA - Domaine Saint Paul', 'INRA Ribeauvillé', 'Domaine le Colombier', 'Lycée agricole de Rivesaltes', 'Station de Tresserre', 'Château Grand Baril', 'SERFEL (SudExpé)', 'INRA - La Grande Ferrade', 'Château les Vergnes', 'Lycée agricole de Rivesaltes', 'Domaine du Chapitre', 'Haroué', 'CEFE', 'EPL D\'ARRAS', 'Ferme du Chaumoy LE SUBDRAY', 'CTIFL Carquefou', 'INRA Alenya', 'GRAB Marguerites', 'INVENIO - Lycée agricole Ste Livrade', 'CTIFL Balandran - Bellegarde', 'SCRADH - Hyeres', 'CREAT - La Gaude', 'Caté - St Pol de Léon', 'Arexhor Seine-Manche', 'GIE Fleurs et Plantes du Sud-Ouest', 'CDHR - Centre Val de Loire', 'CATE', 'Arexhor Grand Est', 'Arexhor Pays de Loire', 'Stepp Bretagne', 'CA 58', 'CA 17', 'CA 53', 'Station SCRADH', 'Doignies', 'Villedieu-sur-Indre', 'Murs', 'Le Rheu', 'ARMEFLHOR', 'EPLEFPA Saint-Paul', 'Saint Joseph', 'Rouffach', 'Bretenière', 'Lusignan', 'Mauguio', 'Estrées-Mons', 'Thiverval-Grignon', 'Crécom', 'Toulouse-Lamothe', 'Dijon-Epoisses'],
    data: [50, 20, 1, 1, 5, 7, 2, 3, 4, 2, 2, 3, 3, 2, 2, 2, 5, 3, 14, 4, 9, 12, 13, 13, 5, 7, 7, 2, 4, 7, 10, 2, 4, 1, 2, 4, 1, 4, 5, 1, 3, 4, 10, 6, 4, 4, 1, 7, 10, 8, 5, 6, 4, 7, 7, 3, 7, 1, 2, 2, 12, 2, 4, 3, 2, 1, 1, 1, 1, 1, 1, 2, 2    ],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6']
};

// Période expérimentation
const periodeExperimentationData = {
    labels: ['2013-2018', '2005-2015', '2012-2013', '2013-2017', '2014-2017', '2014-2019', '2014-2018', '2015-2018', '2012-2016', '2012-2017', '2012-2018', '2012-2019', '2016-2017', '2016-2019', '2016-2018', '2016-2020', '2013-2024', '2013-2022', '2013-2023', '2010-2018', '2011-2017', '2011-2018'],
    data: [72, 36, 4, 42, 13, 2, 25, 3, 6, 48, 18, 1, 3, 1, 11, 1, 1, 1, 2, 1, 3, 2],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF', '#FF33A6', '#33FFF6']
};

// Famille Méthode
const familleMethodeData = {
    labels: ['Micro-organismes', 'Substances naturelles', 'Macro-organismes', 'Médiateurs chimiques', 'Plantes de service', 'Autres méthodes'],
    data: [146, 137, 84, 31, 35, 20],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF']
};

// Sous-famille
const sousFamilleData = {
    labels: ['Préparation bactérienne', 'Préparation fongique', 'Origine minérale', 'Origine végétale', 'Insectes parasitoïdes', 'Insectes prédateurs', 'Stimulateur des défenses', 'Phéromones', 'Plantes attractives', 'Acariens prédateurs', 'Plantes nématicides', 'Préparation virale', 'Plantes répulsives', 'Barrières', 'Plantes pièges', 'Refuge perchoir', 'Plantes de biofumigation', 'Plantes associées', 'Origine végétale et animale', 'Origine bactérienne', 'Effeuillages'],
    data: [66, 34, 52, 25, 36, 26, 4, 22, 12, 12, 7, 6, 6, 6, 5, 3, 5, 7, 2, 3, 4],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF']
};

// Nom Projet
const nomProjetData = {
    labels: ['4SYSLEG', 'BioREco', 'BREIZLEG', 'CanécoH', 'CAP ReD', 'EcoViti Val de Loire-Centre', 'Cors\'Expé', 'DEPHY Carotte', 'DEPHY EXP NPDC', 'DEPHY Fraise', 'DEPHY Serre', 'ECOLEG', 'EcoPêche', 'EcoViti Alsace', 'EcoViti Arc Méditerranéen', 'EcoViti Aquitaine', 'EXPE Ecophyto Lorrain', 'EXPE Ecophyto Pomme', 'EXPE systèmes GC Berry', 'GEDUBAT', 'HORTIFLOR', 'HORTIPEPI', 'HORTIPOT', 'INNOViPEST', 'Otelho', 'PHYTO-SOL', 'Rés0Pest', 'RESCAM', 'Reseau PI', 'SGC Bretagne', 'System-Eco-Puissance4'],
    data: [40, 18, 2, 1, 22, 8, 7, 7, 6, 33, 42, 2, 14, 27, 7, 6, 5, 1, 4, 35, 22, 17, 25, 5, 17, 9, 5, 14, 1, 1, 4],
    backgroundColors: ['#FF5733', '#33FF57', '#5733FF']
};
let currentChart = null; // Variable pour garder une référence du graphique actuel

function initChart(chartId, chartType, chartData) {
    const ctx = document.getElementById(chartId).getContext('2d');

    // Si un graphique existe déjà, on le détruit avant d'en créer un nouveau
    if (currentChart) {
        currentChart.destroy(); // Détruire l'ancien graphique
    }

    // Créer un nouveau graphique
    currentChart = new Chart(ctx, {
        type: chartType,  // Le type de graphique, ici 'pie' ou 'doughnut'
        data: {
            labels: chartData.labels,
            datasets: [{
                data: chartData.data,
                backgroundColor: chartData.backgroundColors
            }]
        },
        options: { responsive: true }
    });
}


function showChart(chartData) {
    const chartContainer = document.getElementById('chartcontainer');
    chartContainer.style.display = "block"; // Afficher le conteneur de graphique
    initChart('chart', 'bar', chartData); // Initialiser un nouveau graphique
}

// Fonction pour masquer ou afficher un graphique
function toggleChart(chartData) {
    const chartContainer = document.getElementById('chartcontainer');

    if (chartContainer.style.display === "block") {
        chartContainer.style.display = "none"; // Masquer si déjà affiché
    } else {
        showChart(chartData); // Afficher le graphique
    }
}

// Liens
document.getElementById('link1').onclick = function(event) {
    event.preventDefault();
    toggleChart(groupeCibleData); // Afficher/masquer le graphique du Link 1
};

document.getElementById('link2').onclick = function(event) {
    event.preventDefault();
    toggleChart(ciblePrincipaleData); // Afficher/masquer le graphique du Link 2
};

document.getElementById('link3').onclick = function(event) {
    event.preventDefault();
    toggleChart(modeActionData); // Afficher/masquer le graphique du Link 3
};

document.getElementById('link4').onclick = function(event) {
    event.preventDefault();
    toggleChart(typeTraitementData); // Afficher/masquer le graphique du Link 4
};

document.getElementById('link5').onclick = function(event) {
    event.preventDefault();
    toggleChart(culturesData); // Afficher/masquer le graphique Cultures
};

document.getElementById('link6').onclick = function(event) {
    event.preventDefault();
    toggleChart(partiTraiteData); // Afficher/masquer le graphique Partie Traité
};

document.getElementById('link7').onclick = function(event) {
    event.preventDefault();
    toggleChart(terreOuAbriData); // Afficher/masquer le graphique Pleine Terre ou Abri
};

document.getElementById('link8').onclick = function(event) {
    event.preventDefault();
    toggleChart(stadeApplicationData); // Afficher/masquer le graphique Stade d'application
};

document.getElementById('link9').onclick = function(event) {
    event.preventDefault();
    toggleChart(satisfactionData); // Afficher/masquer le graphique Satisfaction
};

document.getElementById('link10').onclick = function(event) {
    event.preventDefault();
    toggleChart(siteExperimentationData); // Afficher/masquer le graphique Site d'expérimentation
};

document.getElementById('link11').onclick = function(event) {
    event.preventDefault();
    toggleChart(periodeExperimentationData); // Afficher/masquer le graphique Période expérimentation
};

document.getElementById('link12').onclick = function(event) {
    event.preventDefault();
    toggleChart(familleMethodeData); // Afficher/masquer le graphique Famille Méthode
};

document.getElementById('link13').onclick = function(event) {
    event.preventDefault();
    toggleChart(sousFamilleData); // Graphique en donut pour Sous-famille
};

document.getElementById('link14').onclick = function(event) {
    event.preventDefault();
    toggleChart(nomProjetData); // Graphique en pie pour Nom Projet
};